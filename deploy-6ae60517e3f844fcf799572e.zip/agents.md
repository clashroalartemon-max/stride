# AGENTS.md — Stride

## Architecture
- Everything lives in `index.html`: one `<style>`, a Firebase `<script type="module">` (puts its API on `window.FB`), and one main `<script>`.
- State: the global `S`, saved to localStorage (`stride.v2`) through `save()`. New fields go into `defaults()` **and** `normalizeState()`.
- Cloud: `users/{uid}` in Firestore. Admin gifts reach other players through fields on that document (`giftCoins`, `giftSteps`, `giftItems`), and the recipient applies them in `claimAdminGifts()`.

## Cases (lootboxes)
- Cases are configured in `S.cases`. `rewards` is a string of the form `type:value*weight@rarity` (rarity is optional; when it is missing it comes from the drop chance via `autoRarity`). Parse it with `parseRewards`, serialize it with `rewardToken`.
- Roulette: `openCaseModal` → `spinCase` → `finishSpin` (on `transitionend`, with a timeout as a fallback). The win is stored in `S.casePending` before the animation and paid out in `grantPending` (`recoverCasePending` pays it on the next launch if the app was closed mid-spin).
- Inventory: `S.caseKeys` holds case id → count. A case given to another player is sent as the token `case:<id>:<n>:<nonce>` in `giftItems`.
- Performance rules for the roulette: animate only `transform` on `.cs-strip` (`will-change`), and read layout once before the spin starts. No animations, filters or blur inside the strip. The edge "curtains" are static gradients. Tick sounds are scheduled up front in Web Audio from the inverse of the same cubic-bezier (`tickTimes`).

## Conventions
- Comments are in Russian. The code is compact, with `$()` as a `getElementById` alias. Use `escapeHtml` for any user string that goes into HTML.
- Sounds are synthesized (`SOUND_DEFS` → `synthSamples`). `playSound` uses Web Audio when the context is active and falls back to `<audio>` otherwise.
- `html.lite` (economy mode) and `html.weak` (weak device) turn off heavy effects. New infinite animations should respect them.
- Make targeted edits and do not rewrite the file wholesale.
